package vn.hunghd.flutterdownloader;

public class DownloadStatus {
    public static int UNDEFINED = 0;
    public static int ENQUEUED = 1;
    public static int RUNNING = 2;
    public static int COMPLETE = 3;
    public static int FAILED = 4;
    public static int CANCELED = 5;
    public static int PAUSED = 6;
}
